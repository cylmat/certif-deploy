<?php

declare(strict_types=1);

$config = [
    'defined' => 'config',
];
