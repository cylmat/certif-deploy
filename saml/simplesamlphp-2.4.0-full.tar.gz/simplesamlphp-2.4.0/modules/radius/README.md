# Module for RADIUS authentication

![Build Status](https://github.com/simplesamlphp/simplesamlphp-module-radius/workflows/CI/badge.svg?branch=master)
[![Coverage Status](https://codecov.io/gh/simplesamlphp/simplesamlphp-module-radius/branch/master/graph/badge.svg)](https://codecov.io/gh/simplesamlphp/simplesamlphp-module-radius)
[![Scrutinizer Code Quality](https://scrutinizer-ci.com/g/simplesamlphp/simplesamlphp-module-radius/badges/quality-score.png?b=master)](https://scrutinizer-ci.com/g/simplesamlphp/simplesamlphp-module-radius/?branch=master)
[![Type Coverage](https://shepherd.dev/github/simplesamlphp/simplesamlphp-module-radius/coverage.svg)](https://shepherd.dev/github/simplesamlphp/simplesamlphp-module-radius)
[![Psalm Level](https://shepherd.dev/github/simplesamlphp/simplesamlphp-module-radius/level.svg)](https://shepherd.dev/github/simplesamlphp/simplesamlphp-module-radius)
