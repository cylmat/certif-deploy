# Consent module

![Build Status](https://github.com/simplesamlphp/simplesamlphp-module-consent/actions/workflows/php.yml/badge.svg)
[![Coverage Status](https://codecov.io/gh/simplesamlphp/simplesamlphp-module-consent/branch/master/graph/badge.svg)](https://codecov.io/gh/simplesamlphp/simplesamlphp-module-consent)
[![Scrutinizer Code Quality](https://scrutinizer-ci.com/g/simplesamlphp/simplesamlphp-module-consent/badges/quality-score.png?b=master)](https://scrutinizer-ci.com/g/simplesamlphp/simplesamlphp-module-consent/?branch=master)
[![Type Coverage](https://shepherd.dev/github/simplesamlphp/simplesamlphp-module-consent/coverage.svg)](https://shepherd.dev/github/simplesamlphp/simplesamlphp-module-consent)
[![Psalm Level](https://shepherd.dev/github/simplesamlphp/simplesamlphp-module-consent/level.svg)](https://shepherd.dev/github/simplesamlphp/simplesamlphp-module-consent)
